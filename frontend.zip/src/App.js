import React, { useState, useRef } from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import NotePanel from './components/NotesPanel';
import ChatBar from './components/ChatBar';

function App() {
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [notesVisible, setNotesVisible] = useState(false);
  const [isDashboardEnabled, setIsDashboardEnabled] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [fileUploaded, setFileUploaded] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [generatedQuestions, setGeneratedQuestions] = useState([]); // New state for questions
  const fileInputRef = useRef(null);

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setUploadedFiles(prev => [...prev, ...files]);
    setIsDashboardEnabled(true);
    setFileUploaded(true);
  };

  const handleNotesToggle = () => setNotesVisible(!notesVisible);

  const handleHome = () => {
    setUploadedFiles([]);
    setIsDashboardEnabled(false);
    setChatInput("");
    setFileUploaded(false);
    setGeneratedQuestions([]); // Reset questions when going home
  };

  const handleInputChange = (e) => {
    setChatInput(e.target.value);
  };

  const handleGenerateQuestions = async () => {
    const formData = new FormData();

    // Check if there's an uploaded file or chat input
    if (uploadedFiles.length > 0) {
      formData.append("file", uploadedFiles[0]); // support only one file at a time for now
    } else if (chatInput.trim()) {
      formData.append("text", chatInput);
    } else {
      alert("Please provide either a file or text input");
      return;
    }

    try {
      const response = await fetch("http://localhost:8000/process/", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      if (data.questions) {
        console.log("Generated Questions:", data.questions);
        
        // Assuming each item in `data.questions` is an object with properties like 'question', 'cosine_similarity', 'perplexity'
        const questions = data.questions.map(item => item.question); // Extract only the 'question' field
        
        setGeneratedQuestions(questions); // Update state with the question strings
      } else {
        alert("No questions generated: " + (data.error || "Unknown error"));
      }
    } catch (error) {
      console.error("Error generating questions:", error);
    }
  };

  const handleDeleteFile = (index) => {
    const updatedFiles = uploadedFiles.filter((_, i) => i !== index);
    setUploadedFiles(updatedFiles);
    if (updatedFiles.length === 0) {
      setFileUploaded(false);
      setIsDashboardEnabled(false);
    }
  };

  const toggleSidebar = () => setSidebarVisible(!sidebarVisible);

  return (
    <div className="app-container">
      {/* Hamburger shows only when sidebar is hidden */}
      {!sidebarVisible && (
        <button className="hamburger-btn" onClick={toggleSidebar}>
          &#9776;
        </button>
      )}

      {/* Sidebar */}
      {sidebarVisible && (
        <Sidebar
          onHome={handleHome}
          onNotesToggle={handleNotesToggle}
          isDashboardEnabled={isDashboardEnabled}
          uploadedFiles={uploadedFiles}
          onDeleteFile={handleDeleteFile}
        />
      )}

      <main className="main-content" style={{ marginLeft: sidebarVisible ? '250px' : '0' }}>
        {/* Hidden File Input */}
        <input
          type="file"
          multiple
          ref={fileInputRef}
          style={{ display: 'none' }}
          onChange={handleFileUpload}
        />

        <div className="system-name">LumiLearn</div>
        <h1>Planting the seeds of knowledge</h1>

        {/* Display Generated Questions */}
        {generatedQuestions.length > 0 && (
          <div className="generated-questions">
            <h3>Generated Questions:</h3>
            <ul>
              {generatedQuestions.map((question, index) => (
                <li key={index}>{question}</li> 
              ))}
            </ul>
          </div>
        )}

        {/* ChatBar with updated props */}
        <ChatBar
          fileInputRef={fileInputRef}
          onFileUpload={(file) => {
            setUploadedFiles(prev => [...prev, file]);
            setIsDashboardEnabled(true);
            setFileUploaded(true);
          }}
          chatInput={chatInput}
          handleInputChange={handleInputChange}
          handleGenerateQuestions={handleGenerateQuestions}
          fileUploaded={fileUploaded}
        />

        {/* Notes Panel */}
        <NotePanel
          notesVisible={notesVisible}
          setNotesVisible={setNotesVisible}
        />
      </main>
    </div>
  );
}

export default App;
