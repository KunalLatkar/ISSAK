import React, { useState } from 'react';
import './Sidebar.css';
import UploadedFileItem from './UploadedFileItem';

function Sidebar({ onHome, onNotesToggle, isDashboardEnabled, uploadedFiles, onDeleteFile }) {
  const [isSidebarVisible, setSidebarVisible] = useState(true);

  const toggleSidebar = () => {
    setSidebarVisible(!isSidebarVisible);
  };

  return (
    <div>
      {/* Hamburger Menu outside Sidebar */}
      <div className={`hamburger-menu ${isSidebarVisible ? 'visible' : 'visible'}`} onClick={toggleSidebar}>
        <span className="hamburger-icon">&#9776;</span>
      </div>

      {/* Sidebar */}
      <aside className={`sidebar ${isSidebarVisible ? '' : 'hidden'}`}>
        {/* Section for Buttons */}
        <div className="sidebar-buttons">
          <button className="sidebar-button" onClick={onHome}>Home</button>
          <button className="sidebar-button" onClick={onNotesToggle}>Notes</button>
          <button className="sidebar-button" disabled={!isDashboardEnabled}>Dashboard</button>
        </div>

        {/* Section for Uploaded Files */}
        <div className="uploaded-files-section">
          {uploadedFiles.length > 0 ? (
            <>
              <h4>Uploaded Files</h4>
              {uploadedFiles.map((file, index) => (
                <UploadedFileItem
                  key={index}
                  file={file}
                  onDelete={() => onDeleteFile(index)} // Pass delete functionality to each file item
                />
              ))}
            </>
          ) : (
            <p>No files uploaded yet.</p>
          )}
        </div>
      </aside>
    </div>
  );
}

export default Sidebar;
