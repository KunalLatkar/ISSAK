import React, { useState, useEffect } from 'react';
import './NotesPanel.css'; // Optional: use this for note panel-specific styles

function NotePanel({ notesVisible, setNotesVisible }) {
  const [noteContent, setNoteContent] = useState("");

  // Save the notes content when the component re-renders or when the notes are toggled.
  useEffect(() => {
    const savedNotes = localStorage.getItem("notes");
    if (savedNotes) {
      setNoteContent(savedNotes);
    }
  }, []);

  const handleSaveNotes = () => {
    localStorage.setItem("notes", noteContent);
    alert("Notes saved successfully!");
  };

  const handleDownloadNotes = () => {
    const blob = new Blob([noteContent], { type: "text/plain;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "notes.txt";
    link.click();
  };

  const handleClose = () => {
    setNotesVisible(false);
  };

  return (
    notesVisible && (
      <div className="notes-panel">
        <div className="notes-header">
          <button className="close-btn" onClick={handleClose}>×</button>
          <h3>Notes</h3>
        </div>
        <textarea
          value={noteContent}
          onChange={(e) => setNoteContent(e.target.value)}
          placeholder="Write your notes here..."
        />
        <div className="notes-footer">
          <button className="save-btn" onClick={handleSaveNotes}>Save Notes</button>
          <button className="download-btn" onClick={handleDownloadNotes}>Download Notes</button>
        </div>
      </div>
    )
  );
}

export default NotePanel;
