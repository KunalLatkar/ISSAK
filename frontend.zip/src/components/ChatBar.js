import React, { useState, useRef } from 'react';
import './ChatBar.css';

function ChatBar({ onFileUpload, chatInput, handleInputChange, handleGenerateQuestions, uploadedFiles }) {
  const fileInputRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      onFileUpload(file);
    });
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    await handleGenerateQuestions();
    setIsLoading(false);
  };

  return (
    <div className="chatbar-container">
      <div className={`chatbar-loader ${isLoading ? 'animate' : ''}`}>
        <div className="chatbar-gradient">
          <div className="chatbar-content">
            {/* Upload Button */}
            <label
              htmlFor="file-upload"
              className="upload-btn"
              onClick={() => fileInputRef.current.click()}
            >
              +
            </label>
            <input
              type="file"
              id="file-upload"
              style={{ display: 'none' }}
              ref={fileInputRef}
              multiple
              onChange={handleFileChange}
            />

            {/* Chat input */}
            <input
              type="text"
              placeholder="Enter your message..."
              className="chat-input"
              value={chatInput}
              onChange={handleInputChange}
            />

            {/* Generate Questions button */}
            <button
              className="generate-btn"
              onClick={handleGenerate}
              disabled={!chatInput.trim()}
            >
              Generate Questions
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChatBar;
