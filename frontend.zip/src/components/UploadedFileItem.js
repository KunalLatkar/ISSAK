import React from 'react';
import './UploadedFileItem.css';

function UploadedFileItem({ file, onDelete }) {
  return (
    <div className="uploaded-file-item">
      <span className="file-name">{file.name}</span>
      {/* Delete icon */}
      <span className="delete-icon" onClick={onDelete}>×</span>
    </div>
  );
}

export default UploadedFileItem;
