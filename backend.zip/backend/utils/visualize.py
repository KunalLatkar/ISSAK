import matplotlib.pyplot as plt
import seaborn as sns
import base64
import io
from collections import Counter
from nltk import pos_tag, word_tokenize, ngrams
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def to_base64(plt_figure):
    buf = io.BytesIO()
    plt_figure.savefig(buf, format='png')
    buf.seek(0)
    return base64.b64encode(buf.read()).decode('utf-8')

def generate_all_visuals(questions, scores):
    visuals = {}

    # Cosine Similarity Plot
    fig, ax = plt.subplots()
    ax.bar(range(len(scores)), scores)
    ax.set_title("Cosine Similarity Scores")
    visuals["cosine_bar"] = to_base64(fig)
    plt.clf()

    # POS Tag Plot
    tags = [tag for q in questions for word, tag in pos_tag(word_tokenize(q))]
    tag_counts = Counter(tags)
    fig, ax = plt.subplots()
    sns.barplot(x=list(tag_counts.keys()), y=list(tag_counts.values()), ax=ax)
    ax.set_title("POS Tag Frequency")
    visuals["pos_tags"] = to_base64(fig)
    plt.clf()

    # Bigram Plot
    bigrams = Counter(ngrams(' '.join(questions).lower().split(), 2)).most_common(10)
    fig, ax = plt.subplots()
    sns.barplot(x=[f"{b[0][0]} {b[0][1]}" for b in bigrams], y=[b[1] for b in bigrams], ax=ax)
    ax.set_title("Top Bigrams")
    visuals["bigrams"] = to_base64(fig)
    plt.clf()

    # Heatmap
    tfidf = TfidfVectorizer().fit_transform(questions)
    matrix = cosine_similarity(tfidf)
    fig, ax = plt.subplots()
    sns.heatmap(matrix, annot=True, ax=ax)
    ax.set_title("Question Similarity Heatmap")
    visuals["heatmap"] = to_base64(fig)
    plt.clf()

    return visuals
