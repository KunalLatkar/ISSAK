import cv2
import numpy as np
import easyocr
from PIL import Image
import io

# Initialize EasyOCR reader once
reader = easyocr.Reader(['en'])

def extract_text_from_image(file: bytes) -> str:
    try:
        image = Image.open(io.BytesIO(file))
        img_array = np.array(image)
        img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        results = reader.readtext(img_bgr)
        extracted_text = " ".join([text for _, text, _ in results])
        return extracted_text.strip()
    except Exception as e:
        raise RuntimeError(f"Error extracting text from image: {str(e)}")
