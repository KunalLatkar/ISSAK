import io
from pdfminer.high_level import extract_text
from pdfminer.layout import LAParams

def extract_text_from_pdf(file: bytes) -> str:
    try:
        with io.BytesIO(file) as f:
            text = extract_text(f, laparams=LAParams())
            return text.strip()
    except Exception as e:
        raise RuntimeError(f"Error extracting text from PDF: {str(e)}")
