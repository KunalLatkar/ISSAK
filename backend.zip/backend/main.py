from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from utils.ocr import extract_text_from_image
from utils.pdf import extract_text_from_pdf
from model.question_gen import generate_questions  # assume this is implemented
from model.scoring import rank_questions, compute_perplexity  # import ranking and scoring functions
from utils.visualize import generate_all_visuals  # for generating visuals (if applicable)

app = FastAPI()

# Allow CORS for frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with your React frontend URL in production, e.g., ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/process/")  # Endpoint to process input, either from file or text
async def process_input(file: UploadFile = File(None), text: str = Form(None)):
    try:
        # Variable to hold the extracted text
        extracted_text = ""
        
        # Extract text from file if provided
        if file:
            contents = await file.read()
            if file.filename.endswith(".pdf"):
                extracted_text = extract_text_from_pdf(contents)
            else:
                extracted_text = extract_text_from_image(contents)
        
        # If no file is uploaded, extract from the provided text
        elif text:
            extracted_text = text
        
        # If no input is provided, return error message
        else:
            return {"error": "No input provided"}
        
        # Generate questions from the extracted text
        questions = generate_questions(extracted_text)
        
        # Rank the questions based on the text
        ranked = rank_questions(extracted_text, questions)
        
        # Calculate perplexity for each question
        for q in ranked:
            q["perplexity"] = compute_perplexity(q["question"])
        
        # Generate visuals for the questions (if applicable)
        visuals = generate_all_visuals([q["question"] for q in ranked], [q["cosine_similarity"] for q in ranked])
        
        return {
            "questions": ranked,
            "visuals": visuals  # return visuals with ranked questions
        }
    except Exception as e:
        return {"error": str(e)}

@app.get("/")
def root():
    return {"message": "NLP backend is running"}
