from transformers import T5Tokenizer, T5ForConditionalGeneration
import torch

model_dir = "D:/BTech/sem5/CC-NLP/nlp_project/nlp_model_T5"
tokenizer = T5Tokenizer.from_pretrained(model_dir)
model = T5ForConditionalGeneration.from_pretrained(model_dir)

def generate_questions(text, num_questions=5, max_length=50):
    input_text = "Generate Question: " + text
    inputs = tokenizer(input_text, return_tensors="pt")
    questions = []
    for _ in range(num_questions):
        outputs = model.generate(**inputs, max_length=max_length, do_sample=True,
                                 top_k=50, top_p=0.95, temperature=0.7)
        questions.append(tokenizer.decode(outputs[0], skip_special_tokens=True))
    return questions
