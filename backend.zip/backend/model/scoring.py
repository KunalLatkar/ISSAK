from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import GPT2LMHeadModel, GPT2TokenizerFast
import torch

gpt2 = GPT2LMHeadModel.from_pretrained("gpt2")
gpt2_tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")

def calculate_cosine_similarity(a, b):
    vec = TfidfVectorizer()
    matrix = vec.fit_transform([a, b])
    return cosine_similarity(matrix[0], matrix[1])[0][0] if matrix.shape[1] > 0 else 0.0

def compute_perplexity(sentence):
    encodings = gpt2_tokenizer(sentence, return_tensors="pt")
    with torch.no_grad():
        logits = gpt2(**encodings, labels=encodings["input_ids"]).logits
    loss = torch.nn.functional.cross_entropy(logits.view(-1, logits.size(-1)), encodings["input_ids"].view(-1))
    return torch.exp(loss).item()

def rank_questions(reference, questions):
    return sorted([
        {
            "question": q,
            "cosine_similarity": calculate_cosine_similarity(reference, q)
        } for q in questions
    ], key=lambda x: x["cosine_similarity"], reverse=True)
